def lambdahandler(event, context):
    print("Hellow world")